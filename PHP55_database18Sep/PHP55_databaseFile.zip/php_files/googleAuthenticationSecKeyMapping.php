<?php

/* Google App Client Id */
define('CLIENT_ID', '779418364273-35dsikhnlcgjnjuqu15q2hriun0snmr4.apps.googleusercontent.com');

/* Google App Client Secret */
define('CLIENT_SECRET', 'TTwpltMZ_VFtvrRsz0IQmzWY');

/* Google App Redirect Url */
define('CLIENT_REDIRECT_URL', 'http://localhost:8000/gauth.php');

?>