<div class="container-fluid text-center text-md-left">
    <div class="col-sm-3">
        <img src="../images/Differencing_logo3.png" align="left">
        
    </div>
    <div class="col-sm-6">
        <h2><b>LearnDifferences.org</b></h2>
    </div>
    <div class="col-sm-3 ">
        <div class="container-fluid">
             <div class="row">
               <?php 
                                                $googleadsensecode='
                                                <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
                                                <script>
                                                (adsbygoogle = window.adsbygoogle || []).push({
                                                    google_ad_client: "ca-pub-1881482997365438",
                                                    enable_page_level_ads: true});
                                                    </script>';

                                                echo $googleadsensecode;
                                                ?> 
            </div>
           
        
        </div>
    </div>
</div>

